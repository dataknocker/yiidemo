<div id="dbgpv-php-info">
    <?php echo $this->getPhpInfoContent() ?>
</div>
